create definer = root@localhost trigger credit3
    after delete
    on studentcourse
    for each row
BEGIN
	UPDATE student SET completedCredits=
	(SELECT sum(credit) as sum FROM course,courseclass,studentcourse WHERE
	studentcourse.studentID=old.studentID and
	studentcourse.score>60 and
	studentcourse.courseClassID=courseclass.courseClassID and
	course.courseID=courseclass.courseID);
END;

