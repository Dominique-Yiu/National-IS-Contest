create definer = root@localhost trigger check_male
    after insert
    on male
    for each row
begin
        declare count int;
        declare message varchar(200);
        set count = (select count(*) from male);
        set count = count + (select count(*) from female);
        if (count >= 5)
            then
            set message = 'Invalid Operation, the number of visitors has been out of range 50.';
            signal sqlstate 'HY000' set message_text  = message;
        end if;
    end;

