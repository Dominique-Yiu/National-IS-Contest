create definer = root@localhost trigger check_female
    after insert
    on female
    for each row
begin
        declare count int;
        declare message varchar(200);
        set count = (select count(*) from female);
        set count = count + (select count(*) from male);
        if (count >= 5)
            then
            set message = 'Invalid Operation, the number of visitors has been out of range 50.';
            signal sqlstate 'HY000' set message_text  = message;
        end if;
    end;

