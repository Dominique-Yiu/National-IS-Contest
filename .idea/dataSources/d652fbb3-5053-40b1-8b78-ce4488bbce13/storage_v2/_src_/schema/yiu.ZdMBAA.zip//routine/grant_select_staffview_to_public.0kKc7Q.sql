create
    definer = root@localhost procedure grant_select_staffview_to_public()
begin
    declare v_user char(32);
    declare v_host char(32);
    declare done int default false;
    declare cur cursor for select  user, host from mysql.user;
    declare continue handler for not found set done = true;

    open cur;
    fetch cur into v_user, v_host;

    while not done DO
        set @query = concat('grant select on staff_view to \'', v_user, '\'@\'', v_host, '\'');
        prepare statement from @query;
        execute statement;
        deallocate prepare statement;
        fetch cur into v_user, v_host;
    end while;

    close cur;
end;

