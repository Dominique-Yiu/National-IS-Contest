create definer = root@localhost view department_salary as
select `yiu`.`department`.`Dname`   AS `Dname`,
       max(`yiu`.`staff`.`Ssalary`) AS `max(Ssalary)`,
       min(`yiu`.`staff`.`Ssalary`) AS `min(Ssalary)`,
       avg(`yiu`.`staff`.`Ssalary`) AS `avg(Ssalary)`
from `yiu`.`staff`
         join `yiu`.`department`
where (`yiu`.`staff`.`Sdeptno` = `yiu`.`department`.`Ddeptno`)
group by `yiu`.`staff`.`Sdeptno`;

grant select on table department_salary to yl;

