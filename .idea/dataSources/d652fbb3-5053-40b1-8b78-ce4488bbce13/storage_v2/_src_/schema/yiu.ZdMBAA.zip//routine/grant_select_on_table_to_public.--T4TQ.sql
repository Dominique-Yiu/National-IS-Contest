create
    definer = root@localhost procedure grant_select_on_table_to_public()
begin
    declare  v_user char(32);
    declare  v_host char(32);
    declare  done int default false;    # 定义结束标志
    declare cur cursor for select user, host from mysql.user;   # 定义游标 用户和地址
    declare continue handler for not found set done = true;     # 定义not found一场的handler

    open cur;   # 打开游标
    fetch cur into v_user, v_host;  # 取一行数据

    while not done do
        set @query = concat('grant select on yiu.class to \'', v_user, '\'@\'', v_host, '\'');
        prepare  statement from @query;
        execute  statement;

        set @query = concat('show grants for \'', v_user, '\'@\'', v_host,'\'');
        prepare  statement from @query;
        execute  statement;
        deallocate prepare  statement;
        fetch  cur into v_user, v_host;
    end while;

    close cur;
end;

