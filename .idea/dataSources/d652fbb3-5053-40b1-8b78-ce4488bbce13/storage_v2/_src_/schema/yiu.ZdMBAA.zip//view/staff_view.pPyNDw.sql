create definer = root@localhost view staff_view as
select `yiu`.`staff`.`Sno`     AS `Sno`,
       `yiu`.`staff`.`Sname`   AS `Sname`,
       `yiu`.`staff`.`Sage`    AS `Sage`,
       `yiu`.`staff`.`Stitle`  AS `Stitle`,
       `yiu`.`staff`.`Ssalary` AS `Ssalary`,
       `yiu`.`staff`.`Sdeptno` AS `Sdeptno`
from `yiu`.`staff`
where (concat(`yiu`.`staff`.`Sname`, '@localhost') = user());

grant select on table staff_view to U1@localhost;

grant select on table staff_view to U2@localhost;

grant select on table staff_view to 'mysql.infoschema'@localhost;

grant select on table staff_view to 'mysql.session'@localhost;

grant select on table staff_view to 'mysql.sys'@localhost;

grant select on table staff_view to root@localhost;

grant select on table staff_view to yiu@localhost;

