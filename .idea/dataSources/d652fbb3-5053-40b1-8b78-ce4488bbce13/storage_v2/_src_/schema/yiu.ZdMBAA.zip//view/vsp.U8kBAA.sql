create definer = root@localhost view vsp as
select `yiu`.`spj`.`Sno` AS `Sno`, `yiu`.`spj`.`Pno` AS `Pno`, `yiu`.`spj`.`QTY` AS `QTY`
from `yiu`.`spj`
         join `yiu`.`j`
where ((`yiu`.`spj`.`Jno` = `yiu`.`j`.`Jno`) and (`yiu`.`j`.`Jname` = '三建'));

